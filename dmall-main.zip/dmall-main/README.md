# dmall
Working js Discord Mass Dm bot
